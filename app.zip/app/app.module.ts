import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import {DragDropModule} from '@angular/cdk/drag-drop';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatRadioModule } from '@angular/material/radio';
import {MatButtonModule} from '@angular/material';
import { Scenario1Component } from './Scenario1/Scenario1.component';
import { Scenario2Component } from './Scenario2/Scenario2.component';
import {RouterModule} from '@angular/router';
import {appRoutes} from './app-routing.module'

@NgModule({
  declarations: [
    AppComponent,
    Scenario1Component,
    Scenario2Component
  ],
  imports: [
    BrowserModule,
    FormsModule,
    DragDropModule,
    BrowserAnimationsModule,
    MatRadioModule,
    MatButtonModule,
    RouterModule.forRoot(appRoutes,  {onSameUrlNavigation: 'reload'})
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
