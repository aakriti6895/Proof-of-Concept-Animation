import {AfterViewInit, OnInit, Component} from '@angular/core';
import { jsPlumb } from 'jsplumb';

import * as $ from 'jquery';
import {
  trigger,
  state,
  style,
  animate,
  transition,
  // ...
} from '@angular/animations';
import { callbackify } from 'util';

@Component({
  selector: 'app-Scenario1',
  templateUrl: './Scenario1.component.html',
  styleUrls: ['./Scenario1.component.css'],
  
})
export class Scenario1Component implements OnInit{
    jsPlumbInstance;
    showConnectionToggle = false;
    buttonName = 'Connect';
    connectSourceToTargetUsingJSPlumb() {
      let labelName;
        labelName = 'connection';
        this.jsPlumbInstance.connect({
          connector: ['Flowchart', {stub: [212, 67], cornerRadius: 1, alwaysRespectStubs: true}],
          source: 'pub',
          target: 'broker',
          anchor: ['Right', 'Left'],
          paintStyle: {stroke: '#456', strokeWidth: 4,   gradient:{
            stops:[[0,'red'], [0.33,'blue'], [0.66,'green'], [0.33,'blue'], [1,'red']]
          },},
          endpointStyle:{ fillStyle:"blue", outlineColor:"black", outlineWidth:1 },
    endpointHoverStyles:[ 
        { fillStyle:"red" }, 
        { fillStyle:"yellow" } 
    ],
          hoverPaintStyle:{ strokeStyle:"red" },
          overlays: [
            ['Label', {label: labelName, location: 0.5, cssClass: 'connectingConnectorLabel'}]
          ],
          dragOptions:{
            cursor:'crosshair'
          },
        });


        
        this.jsPlumbInstance.connect({
          connector: ['Flowchart', {stub: [212, 67], cornerRadius: 1, alwaysRespectStubs: true}],
          source: 'broker',
          target: 'sub',
          anchor: ['Right', 'Left'],
          paintStyle: {stroke: '#456', strokeWidth: 4,   gradient:{
            stops:[[0,'red'], [0.33,'blue'], [0.66,'green'], [0.33,'blue'], [1,'red']]
          },},
          endpointStyle:{ fillStyle:"blue", outlineColor:"black", outlineWidth:1 },
    endpointHoverStyles:[ 
        { fillStyle:"red" }, 
        { fillStyle:"yellow" } 
    ],
          hoverPaintStyle:{ strokeStyle:"red" },
          overlays: [
            ['Label', {label: labelName, location: 0.5, cssClass: 'connectingConnectorLabel'}]
          ],
          dragOptions:{
            cursor:'crosshair'
          },
        });

        this.jsPlumbInstance.connect({
          connector: ['Flowchart', {stub: [212, 67], cornerRadius: 1, alwaysRespectStubs: true}],
          source: 'pub1',
          target: 'broker',
          anchor: ['Right', 'Left'],
          paintStyle: {stroke: '#456', strokeWidth: 4,   gradient:{
            stops:[[0,'red'], [0.33,'blue'], [0.66,'green'], [0.33,'blue'], [1,'red']]
          },},
          endpointStyle:{ fillStyle:"blue", outlineColor:"black", outlineWidth:1 },
    endpointHoverStyles:[ 
        { fillStyle:"red" }, 
        { fillStyle:"yellow" } 
    ],
          hoverPaintStyle:{ strokeStyle:"red" },
          overlays: [
            ['Label', {label: labelName, location: 0.5, cssClass: 'connectingConnectorLabel'}]
          ],
          dragOptions:{
            cursor:'crosshair'
          },
        });


        
        this.jsPlumbInstance.connect({
          connector: ['Flowchart', {stub: [212, 67], cornerRadius: 1, alwaysRespectStubs: true}],
          source: 'broker',
          target: 'sub1',
          anchor: ['Right', 'Left'],
          paintStyle: {stroke: '#456', strokeWidth: 4,   gradient:{
            stops:[[0,'red'], [0.33,'blue'], [0.66,'green'], [0.33,'blue'], [1,'red']]
          },},
          endpointStyle:{ fillStyle:"blue", outlineColor:"black", outlineWidth:1 },
    endpointHoverStyles:[ 
        { fillStyle:"red" }, 
        { fillStyle:"yellow" } 
    ],
          hoverPaintStyle:{ strokeStyle:"red" },
          overlays: [
            ['Label', {label: labelName, location: 0.5, cssClass: 'connectingConnectorLabel'}]
          ],
          dragOptions:{
            cursor:'crosshair'
          },
        });

    }

    ngOnInit() {
    {
     // $(document).ready(function(){
       
        $(".play-animation").click(function(){
          var check_value = $("input[name='r']:checked").val();
          if(check_value == 1){
          $("#packet1").css("visibility", "visible");          
            $("#packet1").css("animation-play-state", "running");
            $("#packet2").css("visibility", "hidden");  }

            if(check_value == 2){
              $("#packet2").css("visibility", "visible");
              $("#packet1").css("visibility", "hidden");  
              $("#sub1").text("Bad Subscriber");
              $("#pub1").text("Bad Publisher");
              $("#packet2").css("animation-play-state", "running");
              }
          
        });
     
        $(".stop-animation").click(function(){
            $("#packet1").css("animation-play-state", "paused");
            $("#packet2").css("animation-play-state", "paused");
        });
  //  });
    

  
      this.jsPlumbInstance = jsPlumb.getInstance();
    
      this.showConnectionToggle = ! this.showConnectionToggle;
      if ( this.showConnectionToggle) {
        this.connectSourceToTargetUsingJSPlumb();
      } else {
        this.jsPlumbInstance.reset();
      }
      
    }
   
    }
  
  }
