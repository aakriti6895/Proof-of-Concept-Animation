import { Routes, RouterModule } from '@angular/router';
import { Scenario1Component } from './Scenario1/Scenario1.component';
import { Scenario2Component } from './Scenario2/Scenario2.component';
import { NgModule } from '@angular/core';
export const appRoutes: Routes = [
  { path: '',
    redirectTo: '/Scenario1Component',
    pathMatch: "full"
  },
  { path: 'Scenario1',
    component: Scenario1Component
  },
  {
    path: 'Scenario2',
    component: Scenario2Component
  }
];
@NgModule
({
  imports: [ RouterModule.forRoot(appRoutes)],
  exports: [RouterModule]
})
export class AppRoutingModule
{

}
export default appRoutes;


